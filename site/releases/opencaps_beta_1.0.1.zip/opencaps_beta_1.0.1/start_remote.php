<?php 
/*
 * OpenCaps
 * http://opencaps.atrc.utoronto.ca
 * 
 * Copyright 2009 Heidi Hazelton
 * Adaptive Technology Resource Centre, University of Toronto
 * 
 * Licensed under the Educational Community License (ECL), Version 2.0. 
 * You may not use this file except in compliance with this License.
 * http://www.opensource.org/licenses/ecl2.php
 * 
 */

define('INCLUDE_PATH', 'include/');
require('include/vitals.inc.php');
require('include/basic_header.inc.php'); 

?>
<script language="JavaScript" src="js/start_remote.js" type="text/javascript"></script>

<h1>Start Captioning!</h1>
<p>Welcome to <strong>OpenCaps</strong>. Please select a project to work on:</p>

<div id="start-tabs"></div>
<div id="start-container">	
	<div>
		<h2 style="font-weight:bold">Open Project</h2>
		<p>Add captions to a remote project.</p>
			
		<form action="javascript:processOpenRemote();" method="post" id="form_open" enctype="multipart/form-data" onsubmit="javascript: return validateOpenForm();">
			<div id="projects"></div>
		</form>
		
	<br style="clear:both" /></div>
	
</div>

<div style="font-size: x-small; text-align:center;clear: both;width:99%; margin-top:2em;"><a href="http://atrc.utoronto.ca">ATRC</a> 2009</div>

</body>
</html>
